import React, { useState } from 'react';

export default function Problem4() {
  const [name, setName] = useState('');
  const [year, setYear] = useState('');
  const [course, setCourse] = useState('');

  const handleOnChange = (event, type) => {
    const value = event.target.value;

    switch (type) {
      case 'name':
        setName(value);
        break;
      case 'year':
        setYear(value);
        break;
      case 'course':
        setCourse(value);
        break;
      default:
        break;
    }
  };

  const user = {
    name: name,
    year: year,
    course: course
  };



  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' onChange={(e) => handleOnChange(e, 'name')}/>
      </div>
      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input 
          type='radio' 
          id='firstYear' 
          name='yearlevel' 
          value='First Year' 
          onChange={(e) => handleOnChange(e, 'year')}
          />
          <label for='firstYear'>First Year</label>
        <br></br>
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year'
          onChange={(e) => handleOnChange(e, 'year')}
          
        />
          <label for='secondYear'>Second Year</label>
        <br></br>
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year'
          onChange={(e) => handleOnChange(e, 'year')}
        />
          <label for='thirdYear'>Third Year</label>
        <br></br>
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year'
          onChange={(e) => handleOnChange(e, 'year')}
        />
          <label for='fourthYear'>Fourth Year</label>
        <br></br>
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fourth Year'
          onChange={(e) => handleOnChange(e, 'year')}
        />
          <label for='fifthYear'>Fifth Year</label>
        <br></br>
        <input 
          type='radio' 
          id='irregular' 
          name='yearlevel' 
          value='Irregular'
          onChange={(e) => handleOnChange(e, 'year')}
          
          />
          <label for='irregular'>Irregular</label>
        <br></br>
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select  onChange={(e) => handleOnChange(e, 'course')}>
          <option value='BSCS' >BSCS</option>
          <option value='BSIT' >BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>
      <div>
        <h>OBJECT</h>
        <p>{JSON.stringify(user)}</p>
      </div>
      
    </>
  );
}
