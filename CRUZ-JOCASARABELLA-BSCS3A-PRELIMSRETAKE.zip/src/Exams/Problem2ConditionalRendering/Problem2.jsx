import { useState } from 'react';

function Problem2() {
  const user = {
    name: 'Hedy Lamarr',
    imageUrl: 'https://i.imgur.com/yXOvdOSs.jpg',
    imageSize: 90,
  };

  const [isToggled, setToggle] = useState(false);

  const toggleBtn = () => {
    setToggle(!isToggled);
  };

  function Profile() {
    return (
      <>
        <h1>{user.name}</h1>
        <img
          className='avatar'
          src={user.imageUrl}
          alt={'Photo of ' + user.name}
          style={{
            width: user.imageSize,
            height: user.imageSize,
          }}
        />
      </>
    );
  }

  function InitialContent() {
    return <h1>User profile is hidden.</h1>;
  }

  return (
    <>
      <div>
        {isToggled ? <InitialContent /> : <Profile />}
      </div>
      <div>
        <button type='button' onClick={toggleBtn}>Show Profile</button>
      </div>
    </>
  );
}

export default Problem2;
