import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(true);


  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 3000); 

    return () => clearTimeout(timer);
  }, []);  

  useEffect(() => {
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
    }, 1000); 
  }, [inputValue]);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' value={inputValue} onChange={(e) => setInputValue(e.target.value)}/>
            <p>{isTyping ? 'User is Typing...' : 'User is idle...'}</p>
          </div>
        </>
      )}
    </>
  );
}
