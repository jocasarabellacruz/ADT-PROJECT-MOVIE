import React from 'react';

function StudInfo() {
  const user = {
    name: 'Jocas Cruz',
    course: 'CS',
    section: '3A'
  };

  return ( 
    <div>
        <h>Name: {user.name}</h>
        <p>Course: {user.course}</p>
        <p>Section: {user.section}</p>
    </div>

  );
}

export default StudInfo;